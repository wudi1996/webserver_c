#include <t_stdio.h>
#include <unistd.h>
#include <t_net.h>
#include "t_main.h"
#include <stdlib.h>
#include <sys/wait.h>
#include <signal.h>

//信号处理函数
void handle(int n){
    wait(NULL);
    return;
}

int main(void){
    //向进程注册信号处理函数
    signal(SIGCHLD,handle);
    //创建socket,返回文件描述符sfd
    int sfd=s_listen(AF_INET,SOCK_STREAM,5566,5);
    if(sfd==-1)return -1;
    while(1){
        int cfd=h_accept(sfd);
        //创建子进程
        pid_t pid=fork();
        if(pid==-1)E_MSG("fork",-1);
        if(pid==0){//子进程执行的代码
            close(sfd);
            t_main(cfd);//业务处理
            close(cfd);
            exit(0);
        }else{//父进程执行的代码
            close(cfd);
        }
    }
    return 0;
}
