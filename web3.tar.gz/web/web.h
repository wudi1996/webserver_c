#ifndef WEB_H_
#define WEB_H_
#include <string.h>
typedef struct{
    char method[32];
    char path[256];
    char proto[32];
}req_t;
typedef struct{
    int code;//404  200
    char *f_type;//text/html image/jpg image/png
}res_t;

#endif
