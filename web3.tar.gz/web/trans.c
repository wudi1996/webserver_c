#include <t_main.h>
#include <unistd.h>
#include <stdio.h>
#include "web.h"

char *work_dir="/home/tarena/html";
//cJson 格式

static int get_request(int fd,req_t *req){
    char buf[1024];
    char path[256];
    int r=read(fd,buf,1024);
    //write(1,buf,r);
    //获取请求头的第一行
    sscanf(buf,"%s %s %s\r\n",\
            req->method,req->path,req->proto);
    if(strcmp(req->path,"/")==0)
        strcpy(req->path,"/index.html");
    //将请求路径转换为服务器的绝对路径
    strcpy(path,work_dir);
    strcat(path,req->path);
    strcpy(req->path,path);
    return 0;
}
static char *get_ftype(const char *file){
    char *p=strrchr(file,'.');
    if(strcmp(p,".jpg")==0)return "image/jpg";
    if(strcmp(p,".png")==0)return "image/png";
    return "text/html";
}

static void do_request(req_t *req,res_t *res){
    char *f_type;
    res->code=(access(req->path,R_OK)?404:200);
    if(res->code==404)
        res->f_type="text/html";
    else
        res->f_type=get_ftype(req->path);
    return;
}
static void response_b(int fd,req_t *rq,res_t *rs){
    char f_line[128];
    sprintf(f_line,"%s %d\r\n",rq->proto,rs->code);
    char content[128];
    sprintf(content,"Content-type:%s\r\n\r\n",rs->f_type);
    write(fd,f_line,strlen(f_line));
    write(fd,content,strlen(content));
    if(rs->code==404){
        char *html=\
        "<html><body><h2>FILE NOT FOUND..!</body></html>";
        write(fd,html,strlen(html));
    }else{
        dup2(fd,1);//将客户端的连接描述符重定位到进程的1号描述符
        execlp("cat","cat",rq->path,NULL);
    }
    return;
}
int t_main(int fd){
    req_t req;
    //获取浏览器的请求信息
    get_request(fd,&req);
    printf("%s %s %s\n",\
            req.method,req.path,req.proto);
    //处理请求信息
    res_t res;
    do_request(&req,&res);
    //根据请求信息,处理请求信息,组织响应头
    response_b(fd,&req,&res);
    return 0;
}
