#include <t_stdio.h>
int main(int argc,char *argv[]){
    FILE *fp=fopen(argv[1],"r");
    if(!fp)E_MSG("fopen",-1);

    fclose(fp);
    return 0;
}
