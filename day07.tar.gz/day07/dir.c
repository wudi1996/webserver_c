#include <t_stdio.h>
#include <sys/types.h>
#include <dirent.h>

int main(int argc,char *argv[]){
    struct dirent *dirp;
    //打开文件夹argv[1]
    DIR *dir=opendir(argv[1]);
    if(dir==NULL)E_MSG("opendir",-1);
    
    printf("opendir success...\n");
    while(1){
        dirp=readdir(dir);
        if(dirp)
            printf("file:%s\tinode:%lu\n",\
                    dirp->d_name,dirp->d_ino);
        else
            break;
    }
    //关闭文件夹流
    closedir(dir);
    return 0;
}
