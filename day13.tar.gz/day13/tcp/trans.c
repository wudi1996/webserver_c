#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>

int t_main(int fd){
    char buf[128];
    while(1){
        //从fd读取数据到buf
        int r=read(fd,buf,128);
        for(int i=0;i<r;i++)
            buf[i]=toupper(buf[i]);
        write(fd,buf,r);
        if(strcmp(buf,"EXIT")==0)break;
    }

    return 0;
}
