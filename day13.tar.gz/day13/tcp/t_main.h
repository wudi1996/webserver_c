#ifndef T_MAIN_H_
#define T_MAIN_H_
int t_main(int);
#endif
