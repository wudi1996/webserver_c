#include <t_stdio.h>
#include <unistd.h>
#include <t_net.h>
#include "t_main.h"

int main(void){
    //创建socket,返回文件描述符sfd
    int sfd=s_listen(AF_INET,SOCK_STREAM,5566,5);
    if(sfd==-1)return -1;
    while(1){
        int cfd=h_accept(sfd);
        t_main(cfd);//业务处理
        close(cfd);
    }
    return 0;
}
