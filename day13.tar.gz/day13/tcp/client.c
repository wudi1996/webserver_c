#include <t_stdio.h>
#include <string.h>
#include <unistd.h>
#include "t_net.h"

int main(int argc,char *argv[]){
    SA4 serv;
    char buf[128];
    char msg[128];
    //创建socket,返回socket的文件描述符fd
    int fd=socket(AF_INET,SOCK_STREAM,0);
    if(fd==-1)E_MSG("socket",-1);
    //初始化服务器的信息
    serv.sin_family=AF_INET;
    serv.sin_port=htons(5566);
    //127.0.0.1  text--->binary
    inet_pton(AF_INET,argv[1], &serv.sin_addr);
    //在fd指定的socket上向服务器发起连接
    int c=connect(fd,(SA *)&serv,sizeof(serv));
    if(c==-1)E_MSG("connect",-1);
    while(1){
        gets(msg);
        //字符串的结束标记也被写到服务器端
        write(fd,msg,strlen(msg)+1);
        //阻塞等待服务器的响应消息
        int r=read(fd,buf,128);
        if(strcmp(buf,"EXIT")==0)break;
        //处理响应消息
        write(1,buf,r);
        printf("\n");
    }
    //关闭本次连接
    close(fd);
    return 0;
}
