#include <t_stdio.h>
#include <t_net.h>
#include <ctype.h>

int main(void){
    char buf[128];
    SA4 src_addr;
    socklen_t src_len;
    int fd=s_bind(AF_INET,SOCK_DGRAM,6677);
    if(fd==-1)return -1;
    while(1){
        src_len=sizeof(SA4);
        //阻塞等待客户端的消息
        int rcv=recvfrom(fd,buf,128,0,\
                (SA *)&src_addr,&src_len);
        if(rcv==-1)E_MSG("recvfrom",-1);
        //消息到达了,处理消息
        for(int i=0;i<rcv;i++)
            buf[i]=toupper(buf[i]);
        //将处理结果发送给客户端
        sendto(fd,buf,rcv,0,(SA *)&src_addr,sizeof(SA4));

    }
    return 0;
}
