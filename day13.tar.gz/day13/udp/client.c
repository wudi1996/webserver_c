#include <t_stdio.h>
#include <t_net.h>
#include <string.h>
#include <unistd.h>

int main(int argc,char *argv[]){
    SA4 dst_addr;
    char buf[128];
    char *msg="this is a test...\n";
    //创建socket,返回该设备的文件描述符
    int fd=socket(AF_INET,SOCK_DGRAM,0);
    if(fd==-1)E_MSG("socket",-1);
    //初始化目标地址的成员
    dst_addr.sin_family=AF_INET;
    dst_addr.sin_port=htons(6677);
    //text--->binary
    inet_pton(AF_INET,argv[1], &dst_addr.sin_addr);
    //向服务器发送消息
    int s=sendto(fd,msg,strlen(msg)+1,0,\
            (SA *)&dst_addr,sizeof(SA4));
    if(s==-1)E_MSG("sendto",-1);
    //阻塞等待服务器的响应消息
    int rcv=recvfrom(fd,buf,128,0,NULL,NULL);
    if(rcv==-1)E_MSG("recvfrom",-1);
    //关闭fd
    close(fd);
    //将处理结果输出到显示器
    write(1,buf,rcv);
    return 0;
}
