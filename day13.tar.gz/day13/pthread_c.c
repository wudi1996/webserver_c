#include <t_stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>

//线程执行的函数
void *doit(void *arg){
    printf("pid:%d..%lu..%s\n",getpid(),pthread_self(),\
            (char *)arg);
    return NULL;
}
int main(void){
    pthread_t tid;
    //创建一个新的线程
    pthread_create(&tid,NULL,doit,"new");
    //当前进程中有两个线程了.这两个线程目前是异步的
    sleep(1);
    doit("main");

    return 0;
}
