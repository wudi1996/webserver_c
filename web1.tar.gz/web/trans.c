#include <t_main.h>
#include <unistd.h>

int t_main(int fd){
    char buf[1024];
    int r=read(fd,buf,1024);
    write(1,buf,r);
    return 0;
}
