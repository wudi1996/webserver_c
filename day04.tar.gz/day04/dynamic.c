#include <stdio.h>
#include <dlfcn.h>
typedef int (*f_t)(int,int);
//通过命令行传递共享库的文件名
//argv[1]
int main(int argc,char *argv[]){
    //加载动态库
    void *handle=dlopen(argv[1],RTLD_NOW);
    if(handle==NULL){
        printf("dlopen failed...%s\n",dlerror());
        return -1;
    }
    printf("haha...\n");
    //获取函数t_sub的入口地址
    f_t f=(f_t)dlsym(handle,"t_sub");
    if(f==NULL){
        printf("%s\n",dlerror());
        return -1;
    }
    //f中存放了函数的入口地址
    printf("5-3=%d\n",f(5,3));
    //关闭动态库.仅仅是引用计数减一
    dlclose(handle);
    return 0;
}
