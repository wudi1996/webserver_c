#include <t_stdio.h>
//#include <errno.h>
//#include <string.h>
//通过命令行传递文件的名字
int main(int argc,char *argv[]){
    FILE *fp=fopen(argv[1],"r");
    if(fp==NULL)E_MSG("fopen",-1);
#if 0
    {
        //errno=-1;
        printf("fopen failed...%d\n",errno);
        printf("%s\n",strerror(errno));
        perror("fopen");
        return -1;
    }
#endif
    printf("fopen success...\n");
    //关闭文件
    fclose(fp);
    return 0;
}
