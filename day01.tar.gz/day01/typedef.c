#include <stdio.h>

int main(void){
    typedef int arr_t[3];
    arr_t a={11,21,31};
    arr_t b[2]={{11,21,31},{16,26,36}};
    printf("a[0]=%d\n",a[0]);
    printf("b[1][1]=%d\n",b[1][1]);
    return 0;
}
