#include <stdio.h>
int main(void){
    int arr[][3]={{11,21,31},{16,26,36}};
    int (*p)[3];
    p=arr;
    printf("arr[1][1]=%d\n",*(*(arr+1)+1));
    printf("arr[1][1]=%d\n",*(*arr+4));
    printf("arr[1][1]=%d\n",*(*(arr+2)-2));
    printf("arr[1][1]=%d\n",*(*(++p)+1));
    return 0;
}
