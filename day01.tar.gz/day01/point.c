#include <stdio.h>

int main(void){
    int val=321;
    char s='k';
    int *p;
    char **q;

    p=&val;
    q=&p;
    printf("&p:%p\n",&p);
    printf("q:%p\n",q);
    printf("p:%p\n",p);
    printf("&val=%p\n",&val);
    printf("*p=%d\n",*p);
    printf("*q=%p\n",*q);
    printf("**q=%d\n",**q);
    return 0;
}
