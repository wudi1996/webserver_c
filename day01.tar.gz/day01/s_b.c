#include <stdio.h>
typedef union {
    short v;
    char s;
}u_t;
int main(void){
#if 0
    short val=0x0001;
    char *p=&val;

    (*p)?printf("small\n"):printf("big\n");
#endif
    u_t h;
    h.v=0x0001;
    (h.s)?printf("small\n"):printf("big\n");
    return 0;
}
