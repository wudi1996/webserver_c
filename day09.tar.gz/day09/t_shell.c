#include <t_stdio.h>
#include <unistd.h>

int main(void){
    char buf[128];
    while(1){
        printf("%s$",get_current_dir_name());
        printf("%s\n",gets(buf));
    }
    return 0;
}
