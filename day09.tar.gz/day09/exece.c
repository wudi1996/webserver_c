#include <t_stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void){
    char *ps_envp[]={"caption=beijing","name=tarena",NULL};
    //创建子进程
    pid_t  pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    if(pid==0){
        execle("./tenv","tenv",NULL,ps_envp);    
    }else{
        wait(NULL);
    }
    return 0;
}
