#include <t_stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc,char *argv[]){
    int m=mkfifo(argv[1],0644);
    if(m==-1)E_MSG("mkfifo",-1);
    return 0;
}
