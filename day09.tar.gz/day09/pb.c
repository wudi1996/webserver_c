#include <t_stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    char buf[128];
    //以读的方式打开文件
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1)E_MSG("open",-1);
    //从管道中读取数据,如果没有进程向管道写,阻塞
    int r=read(fd,buf,128);
    write(1,buf,r);
    close(fd);
    return 0;
}
