#include <t_stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void){
    char *ps_argv[]={"ps","-o","pid,ppid,pgrp,comm",NULL};
    //创建子进程
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    if(pid==0){//子进程执行的代码
        //getchar();
        //子进程继承了父进程的映像
        //使用新的映像退换掉旧的映像
        //ps -o pid,ppid,pgrp,comm
        execvp("ps",ps_argv);
        //以下这段代码只有exec函数执行错误的时候,才能执行
        E_MSG("execlp",-1);
    }else{//父进程执行的代码
        wait(NULL);
    }
    return 0;
}
