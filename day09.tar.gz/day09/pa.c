#include <t_stdio.h>
#include <t_file.h>
#include <string.h>

int main(int argc,char *argv[]){
    char *msg="this is a test...\n";
    //以写的方式打开文件
    int fd=open(argv[1],O_WRONLY);
    if(fd==-1)E_MSG("open",-1);
    //如果没有进程从管道文件中读取数据,阻塞在这里
    write(fd,msg,strlen(msg));
    close(fd);
    return 0;
}
