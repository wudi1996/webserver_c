#include <stdio.h>
#include <unistd.h>
extern char **environ;//指向了当前进程的环境变量列表
int main(void){
    int i;
    for(i=0;environ[i]!=NULL;i++)
        printf("%s\n",environ[i]);
    return 0;
}
