#include <t_stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>

int main(void){
    char buf[128];
    char *msg="this is a test...\n";
    int fd[2];//fd[0] 读  fd[1]  写
    //创建管道
    int p=pipe(fd);
    if(p==-1)E_MSG("pipe",-1);
    //创建子进程,子进程继承父进程的文件描述符
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    if(pid==0){//子进程执行的代码 读
        close(fd[1]);//关闭管道的写端
        //从管道中读取数据到buf中
        //如果管道中没有数据,阻塞等待
        int r=read(fd[0],buf,128);
        //将读取到的数据写到显示器
        write(1,buf,r);
        close(fd[0]);
        exit(0);
    }else{//父进程执行的代码 写
        close(fd[0]);
        write(fd[1],msg,strlen(msg));
        close(fd[1]);
        wait(NULL);
    }
    return 0;
}
