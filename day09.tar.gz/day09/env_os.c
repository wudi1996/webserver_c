#include <t_stdio.h>
#include <stdlib.h>
extern char **environ;
int main(void){
    //获取环境变量caption的值
    char *str=getenv("caption");
    if(str)
        printf("%s\n",str);
    //如果环境变量不存在,添加到进程中
    //如果环境变量存在.overwrite.
    setenv("caption","nanjing",0);
    printf("%s\n",getenv("caption"));
    //删除环境变量
    unsetenv("caption");
    str=getenv("caption");
    if(str==NULL)
        printf("deleted...\n");
    //清除环境变量列表
    clearenv();
    if(environ==NULL)
        printf("clear all...\n");
    return 0;
}

