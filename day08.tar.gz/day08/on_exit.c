#include <stdio.h>
#include <stdlib.h>

void bye(int n,void *arg){
    printf("n=%d\targ=%s\n",n,(char *)arg);
    return;
}

int main(void){
    //向进程注册遗言函数
    on_exit(bye,"u");
    getchar();
    exit(-1);
}
