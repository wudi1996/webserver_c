#include <t_stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void){
    int s;
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    if(pid==0){
        printf("child process...%d\n",getpid());
        getchar();
        exit(-1);
    }else{
        //阻塞等待子进程的终止
        wait(&s);
        if(WIFEXITED(s))
            printf("normal terminate...%d\n",\
                    WEXITSTATUS(s));
        if(WIFSIGNALED(s))
            printf("signal number:%d\n",\
                    WTERMSIG(s));

        printf("parent  process...\n");
    }
    return 0;
}
