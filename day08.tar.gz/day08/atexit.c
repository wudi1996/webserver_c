#include <t_stdio.h>
#include <stdlib.h>
#include <unistd.h>

//遗言函数
void bye(void){
    printf("byebye...\n");
    return;
}
void bye1(void){
    printf("goodbye...\n");
    return;
}
int main(void){
    //向进程注册遗言函数
    atexit(bye);
    atexit(bye1);
    //子进程继承父进程的遗言函数
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    //getchar();
    sleep(1);
    return 0;
}
