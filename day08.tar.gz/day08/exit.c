#include <stdlib.h>
int main(void){
    exit(-1);
}
