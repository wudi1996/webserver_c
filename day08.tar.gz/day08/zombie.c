#include <t_stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void){
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    if(pid==0){
        printf("child process...%d\n",getpid());
    }else{
        sleep(10);
    }
    return 0;
}
