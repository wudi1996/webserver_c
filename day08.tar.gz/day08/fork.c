#include <t_stdio.h>
#include <unistd.h>
 #include <sys/types.h>
int main(void){
    //创建一个子进程
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    if(pid==0){//子进程执行的代码
        sleep(1);
        printf("child process...%d\n",getpid());
        printf("parent of child process..%d\n",\
                getppid());

    
    }else{//父进程执行的代码
        
        printf("parent process...%d\n",getpid());
    }
    //sleep(20);
    return 0;
}
