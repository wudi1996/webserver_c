#include <t_stdio.h>
#include <pthread.h>

#if 0
//可重入函数
void *handle(void *arg){
    int val;
    for(int i=0;i<5000;){
        val=i;
        printf("tid:%lu\ti=%d\n",pthread_self(),i);
        val++;
        i=val;
    }
    return NULL;
}
#endif
pthread_mutex_t mutex;//定义锁类型的变量


int val=0;
void *handle(void *arg){
    int tmp;
    for(int i=0;i<5000;i++){
        //加锁
        pthread_mutex_lock(&mutex);
        tmp=val;
        tmp++;
        printf("tid:%lu\ttmp=%d\n",pthread_self(),tmp);
        val=tmp;

        //解锁
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

int main(void){
    
    //初始化mutex锁
    pthread_mutex_init(&mutex,NULL);
    //创建两个线程
    pthread_t tidA,tidB;
    pthread_create(&tidA,NULL,handle,NULL);
    pthread_create(&tidB,NULL,handle,NULL);
    pthread_join(tidA,NULL);
    pthread_join(tidB,NULL);
    //销毁muex锁
    pthread_mutex_destroy(&mutex);
    return 0;
}
