#include <t_stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

//线程执行函数
void *doit(void *arg){
    for(int i=0;i<5;i++){
        printf("%s\tpid:%d\ttid:%lu\n",\
                (char *)arg,getpid(),pthread_self());
        usleep(5000000);
    }
    return NULL;
}
int main(void){
    pthread_t tid;
    // 创建一个线程
    pthread_create(&tid,NULL,doit,"new");
    //到这里有两个线程
    //这两个线程是异步的
    //将新线程设置为分离状态
    pthread_detach(tid);
    for(int i=0;i<5;i++){
        printf("pid:%d\ttid:%lu\n",\
                getpid(),pthread_self());
        usleep(10000000);
    }

    return 0;
}
