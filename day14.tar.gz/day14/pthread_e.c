#include <t_stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

void *doit(void *arg){
    printf("doit...pid:%d\ttid:%lu\n",\
            getpid(),pthread_self());
    return (void *)1;
}
void *doit1(void *arg){
    printf("doit1...pid:%d\ttid:%lu\n",\
            getpid(),pthread_self());
    pthread_exit((void *)4);
}

void *doit2(void *arg){
    while(1){
        printf("doit2 running...\n");
        sleep(1);
    }
    return NULL;
}

int main(void){
    void *ret;
    pthread_t tid;
    //创建新的线程
    pthread_create(&tid,NULL,doit,NULL);
    //这里已经两个线程
    pthread_join(tid,&ret);//阻塞等待线程的汇合
    printf("doit...%d\n",(int)ret);
    //创建新的线程
    pthread_create(&tid,NULL,doit1,NULL);
    pthread_join(tid,&ret);//阻塞等待线程的汇合
    printf("doit1...%d\n",(int)ret);
    
    pthread_create(&tid,NULL,doit2,NULL);
    sleep(3);
    pthread_cancel(tid);
    pthread_join(tid,&ret);
    if(PTHREAD_CANCELED==(void *)-1)
        printf("doit2 exit code...%d\n",(int)ret);
    return 0;
}
