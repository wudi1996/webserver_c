#include <signal.h>
#include <t_stdio.h>
#include <unistd.h>

void handle(int n){
    printf("recv...%d\n",n);
    return;
}
int main(void){
    //改变信号处理函数
    signal(2,handle);
    pid_t pid=fork();
    if(pid==-1)E_MSG("fork",-1);
    while(1);

    return 0;
}
