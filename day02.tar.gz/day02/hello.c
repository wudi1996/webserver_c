#include <stdio.h>//预处理指令
/*
 * hhjkdfhkjsdhfsdhsdfbjhsdf*/
int main(void){
    printf("hello tarena...\n");
    return 3;
}
