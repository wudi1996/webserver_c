#include "p_math.h"

int t_add(int x,int y){
    return x+y;
}

int t_sub(int x,int y){
    return x-y;
}
