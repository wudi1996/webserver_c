#ifndef P_MATH_H_
#define P_MATH_H_
//函数的声明
int t_add(int,int);
int t_sub(int,int);
int t_mul(int,int);
int t_div(int,int);
#endif
