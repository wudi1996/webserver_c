#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

int main(void){
    char buf[32]="hello beijing";
    char *p=buf;
    printf("pid:%d\n",getpid());
    char *str1="hello beijing";
    char *str2="hello beijing";
    //buf="hello beijing";
    //strcpy(buf,"hello beijing");
    printf("str1=%p\n",str1);
    printf("str2=%p\n",str2);
    printf("&str1=%p\n",&str1);
    printf("&str2=%p\n",&str2);
    printf("buf=%p\n",buf);
    printf("buf=%s\n",buf);
    printf("sizeof(buf)=%d\n",sizeof(buf));
    printf("sizeof(p)=%d\n",sizeof(p));
    getchar();
    return 0;
}
