#include <stdio.h>
int g_val=90;
int main(void){
    int val=321;
    int *p;
    //p=(int *)0x30000000;
    *p=8;
    printf("*p=%d\n",*p);
    return 0;
}
