#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

const int g_val=45; 
void count(void){
    static int i=10;
    printf("++i=%d\n",++i);
    printf("&i=%p\n",&i);
    return;
}

int main(void){
    const int val=300;//只读  

    int *q=&g_val;
    //*q=56;
    printf("val=%d\n",val);
    printf("&val=%p\n",&val);
    char *p=(char *)malloc(128);
    printf("p=%p\n",p);
    printf("pid:%d\n",getpid());
    for(int j=0;j<5;j++)
        count();
    printf("&g_val=%p\n",&g_val);
    strcpy(p,"nihao");
    printf("%s\n",p);
    free(p);
    p=NULL;
    //printf("%s\n",p);

    getchar();
    return 0;
}
