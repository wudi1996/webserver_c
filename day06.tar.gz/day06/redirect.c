#include <t_stdio.h>
#include <t_file.h>
#include <string.h>

int main(int argc,char *argv[]){
    char *msg="this is a test...\n";
    //0 1 2 分别代表
    //打开文件,以写的方式,
    //文件不存在,创建文件,指定文件的权限为0644
    //文件存在,将文件的内容清空
    int flags=O_WRONLY|O_CREAT|O_TRUNC;
    int fd=open(argv[1],flags,0644);
    if(fd==-1)E_MSG("open",-1);
    //保存标准输出描述符
    int s_fd=dup(1);
    dup2(fd,1);
    //关闭文件描述符
    close(fd);
    //向标准输出写消息,其实写到了打开的文件里
    write(1,msg,strlen(msg));
    //恢复标准输出
    dup2(s_fd,1);
    //关闭s_fd
    close(s_fd);
    write(1,msg,strlen(msg));

    return 0;
}
