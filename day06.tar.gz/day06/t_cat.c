#include <t_file.h>
#include <t_stdio.h>

int main(int argc,char *argv[]){
    char buf[128];
    int r;
    //打开文件,以只读方式打开
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1)E_MSG("open",-1);
    while((r=read(fd,buf,128))>0)
        write(1,buf,r);
#if 0 
    {
        //从源文件中读取数据都buf中
        int r=read(fd,buf,128);
        if(r>0)
        //将buf中的数据写入到标准输出
            write(1,buf,r);
        else
            break;
    }
#endif
    //关闭文件描述符
    close(fd);
    return 0;
}
