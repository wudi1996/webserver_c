#include <t_stdio.h>
#include <t_file.h>
int main(int argc,char *argv[]){
    //打开文件,以只读的方式打开文件
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1)E_MSG("open",-1);
    printf("open file %s success...\n",argv[1]);
    //关闭文件描述符
    close(fd);
    return 0;
}
