#include <t_stdio.h>
#include <sys/mman.h>
#include <string.h>
#include <t_file.h>

int main(int argcm,char *argv[]){
    //打开文件,可读可写的方式打开文件
    int fd=open(argv[1],O_RDWR);
    if(fd==-1)E_MSG("open",-1);

    int prot=PROT_READ|PROT_WRITE;
    int flags=MAP_SHARED;
    //将文件映射到进程的虚拟地址空间
    void *p=mmap(NULL,6,prot,flags,fd,0);
    if(p==MAP_FAILED)E_MSG("mmap",-1);
    //到这里p的内容是映射区域的起始地址.
    strcpy(p,"hello");
    //关闭文件描述符,不解除映射
    close(fd);
    //解除映射
    munmap(p,6);
    return 0;
}
