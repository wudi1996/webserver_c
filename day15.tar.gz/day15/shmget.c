#include <t_stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(int argc,char *argv[]){
    //获取一个system v ipc的键值
    key_t key=ftok(argv[1],51);
    if(key==-1)E_MSG("fork",-1);
    printf("key:0x%x\n",key);
    //使用键值获取一个共享内存段的id
    int shmid=shmget(key,1024,IPC_CREAT|0644);
    if(shmid==-1)E_MSG("shmget",-1);
    printf("shmid:%d\n",shmid);
    return 0;
}
