#include <t_stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

typedef int que_t[6];
que_t q;//队列
sem_t p,c;
//生产者线程
void *product(void *arg){
    int tail=0;
    while(1){
        sem_wait(&p);
        q[tail]=rand()%1000+1;
        printf("p:%d\n",q[tail]);
        tail=(tail+1)%6;
        sem_post(&c);
        sleep(rand()%3+1);
    }
    return NULL;
}
//消费者线程
void *consume(void *arg){
    int head=0;
    while(1){
        sem_wait(&c);
        int tmp=q[head];
        q[head]=-1;
        head=(head+1)%6;
        printf("c:%d\n",tmp);
        sem_post(&p);
        sleep(rand()%3+1);
    }
    return NULL;
}

int main(void){
    srand(time(NULL));
    //初始化信号量
    sem_init(&p,0,6);
    sem_init(&c,0,0);
    //创建两个线程
    pthread_t pid,cid;
    pthread_create(&pid,NULL,product,NULL);
    pthread_create(&cid,NULL,consume,NULL);
    //阻塞等待线程汇合
    pthread_join(pid,NULL);
    pthread_join(cid,NULL);
    //销毁信号量
    sem_destroy(&p);
    sem_destroy(&c);
    return 0;
}
