#include <t_stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>

int main(int argc,char *argv[]){
    //获取一个system v ipc的键值
    key_t key=ftok(argv[1],41);
    if(key==-1)E_MSG("fork",-1);
    printf("key:0x%x\n",key);
    return 0;
}
