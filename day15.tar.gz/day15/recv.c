#include <t_stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

//用户自定义的结构体
typedef struct msgbuf{
    long mtype;
    char mtext[128];
}msg_t;

int main(int argc,char *argv[]){
    msg_t msg;
    //获取一个system v ipc的键值
    key_t key=ftok(argv[1],41);
    if(key==-1)E_MSG("ftok",-1);
    printf("key:0x%x\n",key);

    //使用键值获取消息队列的id
    int msqid=msgget(key,IPC_CREAT|0644);
    if(msqid==-1)E_MSG("msgget",-1);
    printf("msqid:%d\n",msqid);
    //向消息队列发送消息
    int rcv=msgrcv(msqid,&msg,128,3,IPC_NOWAIT);
    if(rcv==-1)E_MSG("msgrcv",-1);
    //将接收到的消息输出到显示器
    write(1,msg.mtext,rcv);
    return 0;
}
