#ifndef T_NET_H_
#define T_NET_H_
#include  <sys/types.h>      /*See NOTES */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//类型的定义
typedef struct sockaddr SA;
typedef struct sockaddr_in SA4;
//函数的声明
int s_bind(int domain,int type,uint16_t port);
int s_listen(int ,int ,uint16_t ,int);
//无来电显
int n_accept(int);
//来电显
int h_accept(int);

#endif

