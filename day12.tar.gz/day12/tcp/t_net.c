#include <t_stdio.h>
#include "t_net.h"

int s_bind(int domain,int type,uint16_t port){
    SA4 serv;
    //创建socket,返回文件描述符sfd
    int sfd=socket(domain,type,0);
    if(sfd==-1)E_MSG("socket",-1);
    // 初始化serv的成员
    serv.sin_family=AF_INET;
    serv.sin_port=htons(port);
    //本机所有的ip地址 INADDR_ANY
    serv.sin_addr.s_addr=htonl(INADDR_ANY);
    //将sfd和本地地址绑定
    int b=bind(sfd,(SA *)&serv,sizeof(serv));
    if(b==-1)E_MSG("bind",-1);
    
    return sfd;
}
int s_listen(int domain,int type,\
        uint16_t port,int backlog){
    int fd=s_bind(domain,type,port);
    if (fd==-1)return -1;
    listen(fd,backlog);
    return fd;
}

//无来电显
int n_accept(int fd){
    int cfd=accept(fd,NULL,NULL);
    if(cfd==-1)E_MSG("accept",-1);
    return cfd;
}
//带来电显
int h_accept(int fd){
    char IP[32];
    SA4 cli;
    socklen_t cli_len;
    cli_len=sizeof(SA4);
    int cfd=accept(fd,(SA *)&cli,&cli_len);
    if(cfd==-1)E_MSG("accept",-1);
    inet_ntop(AF_INET,&cli.sin_addr,IP,32);
    printf("%s\n",IP);

    return cfd;
}

