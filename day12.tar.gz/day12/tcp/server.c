#include <t_stdio.h>
#include <unistd.h>
#include <ctype.h>
#include "t_net.h"
int main(void){
    char buf[128];
    //创建socket,返回文件描述符sfd
    int sfd=s_listen(AF_INET,SOCK_STREAM,5566,5);
    if(sfd==-1)return -1;
    while(1){
        int cfd=h_accept(sfd);
        //从连接描述符中读取客户端的请求信息
        int r=read(cfd,buf,128);
        //处理客户端的请求
        int i;
        for(i=0;i<r;i++)
            buf[i]=toupper(buf[i]);
        //将处理发送给客户端
        write(cfd,buf,r);
        //关闭本次连接
        close(cfd);
    }
    return 0;
}
