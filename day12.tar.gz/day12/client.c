#include <t_stdio.h>
#include  <sys/types.h> /*See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc,char *argv[]){
    struct sockaddr_in serv;
    char buf[128];
    char *msg="this is a test...\n";
    //创建socket,返回socket的文件描述符fd
    int fd=socket(AF_INET,SOCK_STREAM,0);
    if(fd==-1)E_MSG("socket",-1);
    //初始化服务器的信息
    serv.sin_family=AF_INET;
    serv.sin_port=htons(5566);
    //127.0.0.1  text--->binary
    inet_pton(AF_INET,argv[1], &serv.sin_addr);
    //在fd指定的socket上向服务器发起连接
    int c=connect(fd,(struct sockaddr *)&serv,\
            sizeof(serv));
    if(c==-1)E_MSG("connect",-1);
    //字符串的结束标记也被写到服务器端
    write(fd,msg,strlen(msg)+1);
    //阻塞等待服务器的响应消息
    int r=read(fd,buf,128);
    //处理响应消息
    write(1,buf,r);
    //关闭本次连接
    close(fd);
    return 0;
}
