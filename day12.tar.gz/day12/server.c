#include <t_stdio.h>
#include  <sys/types.h>      /*See NOTES */
#include <sys/socket.h>
#include <unistd.h>
#include <ctype.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(void){
    char buf[128];
    char IP[32];
    struct sockaddr_in serv,cli;
    socklen_t cli_len;
    //创建socket,返回文件描述符sfd
    int sfd=socket(AF_INET,SOCK_STREAM,0);
    if(sfd==-1)E_MSG("socket",-1);
    // 初始化serv的成员
    serv.sin_family=AF_INET;
    serv.sin_port=htons(5566);
    //本机所有的ip地址 INADDR_ANY
    serv.sin_addr.s_addr=htonl(INADDR_ANY);
    //将sfd和本地地址绑定
    int b=bind(sfd,(struct sockaddr *)&serv,sizeof(serv));
    if(b==-1)E_MSG("bind",-1);
    //将sfd设置为被动连接状态,监听客户端连接的到来
    //客户端连接到来的时候,放入未决连接队列中
    int l=listen(sfd,5);
    if(l==-1)E_MSG("listen",-1);
    while(1){
        cli_len=sizeof(cli);
        //从未决连接队列中取出一个,进行连接处理
        //返回连接文件描述符
        int cfd=accept(sfd,(struct sockaddr *)&cli,\
                &cli_len);
        if(cfd==-1)E_MSG("accept",-1);
        //客户端的ip地址和端口号保存到了cli的空间里
        //binary--->text
        inet_ntop(AF_INET,&cli.sin_addr,IP,32);
        printf("%s\n",IP);
        //从连接描述符中读取客户端的请求信息
        int r=read(cfd,buf,128);
        //处理客户端的请求
        int i;
        for(i=0;i<r;i++)
            buf[i]=toupper(buf[i]);
        //将处理发送给客户端
        write(cfd,buf,r);
        //关闭本次连接
        close(cfd);
    }
    
    return 0;
}
