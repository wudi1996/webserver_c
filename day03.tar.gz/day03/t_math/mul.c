#include "p_math.h"

int t_mul(int x,int y){
    return x*y;
}

int t_div(int x,int y){
    return x/y;
}
